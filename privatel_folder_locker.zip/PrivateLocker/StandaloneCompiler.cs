﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;

namespace PrivateLocker
{
    public static class StandaloneCompiler
    {
        private static List<FileInfo> resourceFiles = new List<FileInfo>();
        
        public static bool CompileExecutable(string sourceName, string resourceDirectory)
        {
            FileInfo sourceFile = new FileInfo(sourceName);
            CodeDomProvider provider = null;
            bool compileOk = false;

            // Select the code provider based on the input file extension. 
            if (sourceFile.Extension.ToUpper(CultureInfo.InvariantCulture) == ".CS")
            {
                provider = CodeDomProvider.CreateProvider("CSharp");
            }
            else if (sourceFile.Extension.ToUpper(CultureInfo.InvariantCulture) == ".VB")
            {
                provider = CodeDomProvider.CreateProvider("VisualBasic");
            }
            else 
            {
                Console.WriteLine("Source file must have a .cs or .vb extension");
            }

            if (provider != null)
            {
                // Format the executable file name. 
                // Build the output assembly path using the current directory 
                String exeName = String.Format(@"{0}\Locker.exe", resourceDirectory);
                
                CompilerParameters cp = new CompilerParameters();

                // Generate an executable instead of  
                // a class library.
                cp.GenerateExecutable = true;

                // Specify the assembly file name to generate.
                cp.OutputAssembly = exeName;

                // Save the assembly as a physical file.
                cp.GenerateInMemory = false;

                // Set whether to treat all warnings as errors.
                cp.TreatWarningsAsErrors = false;

                //Add the Resources
                resourceFiles.Clear();
                GetAllFilesInDir(new DirectoryInfo(resourceDirectory), "*");
                foreach (FileInfo file in resourceFiles)
                {
                    if (file.Name != "standalone.cs")
                    {
                        cp.EmbeddedResources.Add(file.FullName);
                    }
                    if (file.Name == "Lzma.dll")
                    {
                        cp.ReferencedAssemblies.Add(file.FullName);
                    }
                    if (file.Name == "key2.ico")
                    {
                        //Add Icon
                        cp.CompilerOptions = string.Format("/win32icon:{0}", file.FullName);
                    }
                }


                // Invoke compilation of the source file.
                CompilerResults cr = provider.CompileAssemblyFromFile(cp, 
                    sourceName);

                if(cr.Errors.Count > 0)
                {
                    // Display compilation errors.
                    Console.WriteLine("Errors building {0} into {1}",  
                        sourceName, cr.PathToAssembly);
                    foreach(CompilerError ce in cr.Errors)
                    {
                        Console.WriteLine("  {0}", ce.ToString());
                        Console.WriteLine();
                    }
                }
                else
                {
                    // Display a successful compilation message.
                    Console.WriteLine("Source {0} built into {1} successfully.",
                        sourceName, cr.PathToAssembly);
                }

                // Return the results of the compilation. 
                if (cr.Errors.Count > 0)
                {
                    compileOk = false;
                }
                else 
                {
                    compileOk = true;
                }

                if (resourceFiles != null)
                {
                    foreach (FileInfo file in resourceFiles)
                    {
                        try
                        {
                            File.Delete(file.FullName);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                        }
                        
                    }
                }
            }
            return compileOk;
        }

        private static void GetAllFilesInDir(DirectoryInfo dir, string searchPattern)
        {
            // list the files
            try
            {
                foreach (FileInfo f in dir.GetFiles(searchPattern))
                {
                    resourceFiles.Add(f);
                }
            }
            catch
            {
                Console.WriteLine("Directory {0}  \n could not be accessed!!!!", dir.FullName);
            }

            // process each directory
            foreach (DirectoryInfo d in dir.GetDirectories())
            {
                GetAllFilesInDir(d, searchPattern);
            }

        }

        public static void ExtractSourceCode(string path)
        {
            string fInfo = "";
            Assembly asm = Assembly.GetExecutingAssembly();
            Stream fstr = null;
            string asmName = asm.GetName().Name;

            //Loop thru all the resources and Extract them
            foreach (string resourceName in asm.GetManifestResourceNames())
            {
                fInfo = path + "\\res\\" + resourceName.Replace(asmName + ".", "").Replace("Resources.", "");
                fstr = asm.GetManifestResourceStream(resourceName);

                if (fstr != null && fInfo.Contains("standalone.cs"))
                {
                    SaveStreamToFile(fInfo, fstr);
                }

                if (fstr != null && fInfo.Contains("Lzma.dll"))
                {
                    SaveStreamToFile(fInfo, fstr);
                }

                if (fstr != null && fInfo.Contains("key2.ico"))
                {
                    SaveStreamToFile(fInfo, fstr);
                }
            }
        }

        private static void SaveStreamToFile(string fileFullPath, Stream stream)
        {
            if (stream.Length == 0) return;

            if (!Directory.Exists(Path.GetDirectoryName(fileFullPath)))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(fileFullPath));
            }

            // Create a FileStream object to write a stream to a file
            using (FileStream fileStream = System.IO.File.Create(fileFullPath, (int)stream.Length))
            {

                // Fill the bytes[] array with the stream data
                byte[] bytesInStream = new byte[stream.Length];
                stream.Read(bytesInStream, 0, (int)bytesInStream.Length);

                // Use FileStream object to write to the specified file
                fileStream.Write(bytesInStream, 0, bytesInStream.Length);
            }
        }
    }

}
