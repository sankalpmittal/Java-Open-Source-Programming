﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace standalone
{
    class Program
    {
        static void Main(string[] args)
        {
            bool status = false;
            string pw = "";
            string dir = System.Environment.CurrentDirectory + @"\Unlocked";
            Console.WriteLine("Locker Standalone Decrypter");
            Console.WriteLine("---------------------------");
            Console.WriteLine("Enter Password to decrypt:");

            pw = Console.ReadLine();

            if (pw != string.Empty)
            {
                ExtractResources(dir);
                status = EncryptionUtils.DecryptFolder(dir, pw,true);

                if (status)
                {
                    Console.WriteLine("Decryption Completed");
                }
                else
                {
                    try
                    {
                        Thread.Sleep(2000);
                        Directory.Delete(dir, true);
                        Console.WriteLine("Decryption Failed");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);  
                    }
                }
            }

              
        }

        private static void ExtractResources(string dir)
        {
            try
            {
                string fInfo = "";
                Assembly asm = Assembly.GetExecutingAssembly();
                Stream fstr = null;

                //Create The output Directory if it Doesn't Exist
                if (!Directory.Exists(dir))
                {
                    Directory.CreateDirectory(dir);
                }

                //Loop thru all the resources and Extract them
                foreach (string resourceName in asm.GetManifestResourceNames())
                {
                    fInfo = dir + @"\" + resourceName.Replace(asm.GetName().Name + ".Resources.", "");
                    fstr = asm.GetManifestResourceStream(resourceName);

                    if(fInfo.Contains("Lzma"))
                    {
                        fInfo = System.Environment.CurrentDirectory + "\\" + resourceName.Replace(asm.GetName().Name + ".Resources.", "");
                    }

                    if (fstr != null && !fInfo.Contains("key2.ico"))
                    {
                        SaveStreamToFile(fInfo, fstr);
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SaveStreamToFile(string fileFullPath, Stream stream)
        {
            if (stream.Length == 0) return;

            // Create a FileStream object to write a stream to a file
            using (FileStream fileStream = System.IO.File.Create(fileFullPath, (int)stream.Length))
            {
                // Fill the bytes[] array with the stream data
                byte[] bytesInStream = new byte[stream.Length];
                stream.Read(bytesInStream, 0, (int)bytesInStream.Length);

                // Use FileStream object to write to the specified file
                fileStream.Write(bytesInStream, 0, bytesInStream.Length);
            }
        }

    }

    public static class EncryptionUtils
    {
        #region Variables

        static List<FileInfo> files = new List<FileInfo>();  // List that will hold the files and sub files in path
        static List<DirectoryInfo> folders = new List<DirectoryInfo>(); // List that hold directories that cannot be accessed

        #endregion

        #region Public Methods

        public static bool DecryptFolder(string folderDirectory, string pword, bool compressed)
        {
            bool status = false;
            string fileLocation = "";
            string salt = "";
            byte[] encPW = null;

            try
            {
                status = Directory.Exists(folderDirectory);

                if (status)
                {
                    DirectoryInfo di = new DirectoryInfo(folderDirectory);

                    //Clear Folder and File list
                    folders = new List<DirectoryInfo>();
                    files = new List<FileInfo>();
                    //Build new Folder and File list
                    GetAllFilesInDir(di, "*");

                    foreach (FileInfo fi in files)
                    {
                        fileLocation = fi.FullName;

                        if (fi.Name != "key2.ico" && fi.Name != "Lzma.dll")
                        {
                            //Build the Encrypted Password with a unique salt based on the file's info
                            string fileData = string.Format("{0}", fi.Name.Substring(0, fi.Name.IndexOf(".")));
                            salt = Convert.ToBase64String(GetBytes(fileData));
                            encPW = EncryptPassword(pword, "!PrivateLocker-2013", salt);
                            string strPW = Convert.ToBase64String(encPW);

                            DecryptFile(fileLocation, encPW);

                            if (compressed)
                            {
                                DecompressFileLZMA(fi.FullName, fi.FullName.Replace(".zip", ""));

                                //Delete the original file
                                if (File.Exists(fi.FullName))
                                {
                                    File.Delete(fi.FullName);
                                }
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                status = false;
            }

            return status;
        }

        /// <summary>
        /// Encrypt String
        /// </summary>
        /// <param name="clearText">Clear Text to be Encrypted</param>
        /// <param name="password">Password to use during encryption</param>
        /// <param name="salt">Salt to use during Encryption</param>
        /// <returns></returns>
        public static byte[] EncryptPassword(string clearText, string password, string salt)
        {
            byte[] saltBytes = Encoding.Unicode.GetBytes(salt);
            byte[] clearBytes = System.Text.Encoding.Unicode.GetBytes(clearText);
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(password, saltBytes);

            byte[] encryptedData = EncryptPW(clearBytes, pdb.GetBytes(32), pdb.GetBytes(16));
            //return Convert.ToBase64String(encryptedData); //For returning string instead
            return encryptedData;
        }
        #endregion

        #region Private Methods

        private static void GetAllFilesInDir(DirectoryInfo dir, string searchPattern)
        {
            // list the files
            try
            {
                foreach (FileInfo f in dir.GetFiles(searchPattern))
                {
                    //Console.WriteLine("File {0}", f.FullName);
                    files.Add(f);
                }
            }
            catch
            {
                Console.WriteLine("Directory {0}  \n could not be accessed!!!!", dir.FullName);
                return;  // We already got an error trying to access dir so don't try to access it again
            }

            // process each directory
            // If I have been able to see the files in the directory I should also be able 
            // to look at its directories so I don't think I should place this in a try catch block
            foreach (DirectoryInfo d in dir.GetDirectories())
            {
                folders.Add(d);
                GetAllFilesInDir(d, searchPattern);
            }
        }

        private static byte[] EncryptPW(byte[] clearText, byte[] key, byte[] iv)
        {
            MemoryStream ms = new MemoryStream();
            Rijndael alg = Rijndael.Create();
            alg.Key = key;
            alg.IV = iv;
            CryptoStream cs = new CryptoStream(ms, alg.CreateEncryptor(), CryptoStreamMode.Write);
            cs.Write(clearText, 0, clearText.Length);
            cs.Close();
            byte[] encryptedData = ms.ToArray();
            return encryptedData;
        }

        private static void DecryptFile(string inputFile, byte[] key)
        {
            string ext = Path.GetExtension(inputFile);
            string outputFile = inputFile.Replace(ext, "_enc" + ext);

            //Prepare the file for decryption by getting it into a stream
            FileStream fsCrypt = new FileStream(inputFile, FileMode.Open);

            //Setup the Decryption Standard using Read mode
            RijndaelManaged rijndaelCrypto = new RijndaelManaged();
            CryptoStream cs = new CryptoStream(fsCrypt, rijndaelCrypto.CreateDecryptor(key, key), CryptoStreamMode.Read);

            //Write the decrypted file stream
            FileStream fsOut = new FileStream(outputFile, FileMode.Create);
            try
            {
                int data;
                while ((data = cs.ReadByte()) != -1)
                { fsOut.WriteByte((byte)data); }

                //Close all the Writers
                fsOut.Close();
                cs.Close();
                fsCrypt.Close();

                //Delete the original file
                File.Delete(inputFile);
                //Rename the encrypted file to that of the original
                File.Copy(outputFile, inputFile);
                File.Delete(outputFile);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                fsOut = null;
                cs = null;
                fsCrypt = null;
            }
        }

        private static byte[] GetBytes(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        private static void DecompressFileLZMA(string inFile, string outFile)
        {
            SevenZip.Compression.LZMA.Decoder coder = new SevenZip.Compression.LZMA.Decoder();
            FileStream input = new FileStream(inFile, FileMode.Open);
            FileStream output = new FileStream(outFile, FileMode.Create);

            // Read the decoder properties
            byte[] properties = new byte[5];
            input.Read(properties, 0, 5);

            // Read in the decompress file size.
            byte[] fileLengthBytes = new byte[8];
            input.Read(fileLengthBytes, 0, 8);
            long fileLength = BitConverter.ToInt64(fileLengthBytes, 0);

            coder.SetDecoderProperties(properties);
            coder.Code(input, output, input.Length, fileLength, null);

            //Cleanup
            input.Close();
            output.Flush();
            output.Close();
            coder = null;
        }

        #endregion
    }

}